/**
 * Created by FanTaSyLin on 2016/10/18.
 */

(function () {

    'use strict';

    angular.module('Worldview', [
        'ngCookies',
        'ngRoute',
        'ui.sortable'
    ]);
    //    'ngAnimate-animate.css',
})();