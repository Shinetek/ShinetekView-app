/**
 * Created by FanTaSyLin on 2016/10/18.
 */


(function () {

    'use strict';

    angular.module('Worldview')
        .run(WorldviewRun);

    WorldviewRun.$inject = ['$cookies'];

    function WorldviewRun($cookies) {

    }

})();