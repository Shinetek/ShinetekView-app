/**
 * Created by lenovo on 2017/2/24.
 */
//全局参数设置
var Config_Total = {
    /*api获取配置*/
    "BASEPATH": 'http://10.24.4.121:4001/api',
    /*基本图层API*/
    "BASETILEURL": "http://10.24.10.108/IMAGEL2/GBAL/"

};